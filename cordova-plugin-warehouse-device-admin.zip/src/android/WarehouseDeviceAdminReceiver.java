package com.perfectress.warehouse;

import android.app.admin.DeviceAdminReceiver;

public class WarehouseDeviceAdminReceiver extends DeviceAdminReceiver {
  // Empty class for device admin
}
